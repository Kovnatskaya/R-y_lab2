﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace lab2
{
    public partial class Form1 : Form
    {
        private Assembly assembly;

        public Form1()
        {
            InitializeComponent();
        }

        //Получение пути к сборке через OpenFileDialog
        private string selectAssemblyFile()
        {
            openFileDialog1.Filter = "Dll files (*.dll)|*.dll|Exe files(*.exe)|*.exe| All files (*.*)|*.*";
            openFileDialog1.Title = "Select assembly file";
            return (openFileDialog1.ShowDialog() == DialogResult.OK) ?
            openFileDialog1.FileName : null;
        }

        //Загрузка сборки
        private Assembly openAssembly(string path)
        {
            try
            {
                Assembly a = Assembly.LoadFrom(path);
                return a;
            }
            catch (Exception)
            {
                MessageBox.Show("Не удалось загрузить указанную сборку!",
                "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
        //Добавить все классы и интерфейсы сборки к узлу дерева
        void addRoot(TreeNode root, Type[] types)
        {
            TreeNode node = null;
            foreach (Type type in types)
            {
                node = new TreeNode();
                node.Text = type.ToString();
                //Если класс
                if (type.IsClass)
                {
                    node.ImageIndex = 1;
                    node.SelectedImageIndex = 1;
                    addFirstLevel(node, type);
                    root.Nodes.Add(node);
                }
                //Если интерфейс
                else if (type.IsInterface)
                {
                    node.ImageIndex = 0;
                    node.SelectedImageIndex = 0;
                    addFirstLevel(node, type);
                    root.Nodes.Add(node);
                }
                //Если перечисление
                else if (type.IsEnum)
                {
                    node.ImageIndex = 2;
                    node.SelectedImageIndex = 2;
                    addFirstLevel(node, type);
                    root.Nodes.Add(node);
                }
                //Если структура
                else if (type.IsValueType)
                {
                    node.ImageIndex = 3;
                    node.SelectedImageIndex = 3;
                    addFirstLevel(node, type);
                    root.Nodes.Add(node);
                }
            }
        }

        //Загрузить все поля, конструкторы и методы
        private void addFirstLevel(TreeNode node, Type type)
        {
            TreeNode node1 = null;

            FieldInfo[] fields = type.GetFields();
            MethodInfo[] methods = type.GetMethods();
            ConstructorInfo[] constructors = type.GetConstructors();

            //Загрузить поля
            foreach (FieldInfo field in fields)
            {
                node1 = new TreeNode();
                node1.Text = field.FieldType.Name + " " + field.Name;
                node1.ImageIndex = 4;
                node1.SelectedImageIndex = 4;
                node.Nodes.Add(node1);
            }

            //Загрузить конструкторы
            foreach (ConstructorInfo constructor in constructors)
            {
                String s = "";
                ParameterInfo[] parametrs = constructor.GetParameters();
                foreach (ParameterInfo parametr in parametrs)
                {
                    s = s + parametr.ParameterType.Name + ", ";
                }
                s = s.Trim();
                s = s.TrimEnd(',');
                node1 = new TreeNode();
                node1.Text = node.Text + "(" + s + ")";
                node1.ImageIndex = 5;
                node1.SelectedImageIndex = 5;
                node.Nodes.Add(node1);
            }

            //Загрузить методы
            foreach (MethodInfo method in methods)
            {
                String s = "";
                ParameterInfo[] parametrs = method.GetParameters();
                foreach (ParameterInfo parametr in parametrs)
                {
                    s = s + parametr.ParameterType.Name + ", ";
                }
                s = s.Trim();
                s = s.TrimEnd(',');
                node1 = new TreeNode();
                node1.Text = method.ReturnType.Name + " " + method.Name + "("
                + s + ")";
                node1.ImageIndex = 6;
                node1.SelectedImageIndex = 6;
                node.Nodes.Add(node1);
            }
        }
        //показать информацию о сборке
        private void ShowLevel0(TreeNode node)
        {
            listView1.Clear();
            ListViewItem item1 = new ListViewItem("Assembly", 0);
            ListViewItem item2 = new ListViewItem("Name: " + assembly.GetName().Name, 1);
            ListViewItem item3 = new ListViewItem("full name: " + assembly.FullName, 2);
            ListViewItem item4 = new ListViewItem("entry point: " + assembly.EntryPoint, 3);
            listView1.Items.AddRange(new ListViewItem[] { item1, item2, item3, item4 });
        }
        //показать информацию об интерфейсе,классе,перечислении,структуре
        private void ShowLevel1(TreeNode node)
        {
            Type[] types = assembly.GetTypes();
            foreach (Type t in types)
                if (t.ToString() == node.Text)
                {
                    if (t.IsClass)
                    {
                        listView1.Clear();
                        ListViewItem item1 = new ListViewItem("Class", 0);
                        ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                        listView1.Items.AddRange(new ListViewItem[] { item1, item2 });
                        if (t.IsPublic)
                        {
                            ListViewItem item3 = new ListViewItem("public", 2);
                            listView1.Items.AddRange(new ListViewItem[] { item3 });
                        }
                        if (t.IsSerializable)
                        {
                            ListViewItem item4 = new ListViewItem("serializable", 3);
                            listView1.Items.AddRange(new ListViewItem[] { item4 });
                        }
                        if (t.IsAbstract)
                        {
                            ListViewItem item5 = new ListViewItem("abstract", 4);
                            listView1.Items.AddRange(new ListViewItem[] { item5 });
                        }
                        if (t.IsSealed)
                        {
                            ListViewItem item6 = new ListViewItem("final", 5);
                            listView1.Items.AddRange(new ListViewItem[] { item6 });
                        }

                    }
                    else if (t.IsInterface)
                    {
                        listView1.Clear();
                        ListViewItem item1 = new ListViewItem("Interface", 0);
                        ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                        listView1.Items.AddRange(new ListViewItem[] { item1, item2 });
                        if (t.IsPublic)
                        {
                            ListViewItem item3 = new ListViewItem("public", 2);
                            listView1.Items.AddRange(new ListViewItem[] { item3 });
                        }
                        if (t.IsSerializable)
                        {
                            ListViewItem item4 = new ListViewItem("serializable", 3);
                            listView1.Items.AddRange(new ListViewItem[] { item4 });
                        }
                        ListViewItem item5 = new ListViewItem("Base class: " + t.BaseType.Name, 4);
                        listView1.Items.AddRange(new ListViewItem[] { item5 });
                    }
                    else if (t.IsEnum)
                    {
                        listView1.Clear();
                        ListViewItem item1 = new ListViewItem("Enumeration", 0);
                        ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                        listView1.Items.AddRange(new ListViewItem[] { item1, item2 });
                        if (t.IsPublic)
                        {
                            ListViewItem item3 = new ListViewItem("public", 2);
                            listView1.Items.AddRange(new ListViewItem[] { item3 });
                        }
                        ListViewItem item4 = new ListViewItem("Base type: " + t.BaseType.Name, 3);
                        listView1.Items.AddRange(new ListViewItem[] { item4 });
                    }
                    else if (t.IsValueType)
                    {
                        listView1.Clear();
                        ListViewItem item1 = new ListViewItem("Structure", 0);
                        ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                        listView1.Items.AddRange(new ListViewItem[] { item1, item2 });
                        if (t.IsPublic)
                        {
                            ListViewItem item3 = new ListViewItem("public", 2);
                            listView1.Items.AddRange(new ListViewItem[] { item3 });
                        }
                        if (t.IsSerializable)
                        {
                            ListViewItem item4 = new ListViewItem("serializable", 3);
                            listView1.Items.AddRange(new ListViewItem[] { item4 });
                        }
                    }
                    else
                    {
                        listView1.Clear();
                        ListViewItem item1 = new ListViewItem("Unrecognized", 0);
                        ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                        ListViewItem item3 = new ListViewItem("Base Type: " + t.BaseType.Name, 2);
                        listView1.Items.AddRange(new ListViewItem[] { item1, item2, item3 });
                    }
                }
        }

        private void ShowLevel2(TreeNode node)
        {
            Type[] types = assembly.GetTypes();
            String s;
            foreach (Type t in types)
                if (t.ToString() == node.Parent.Text)
                {
                    FieldInfo[] fields = t.GetFields();
                    MethodInfo[] methods = t.GetMethods();
                    ConstructorInfo[] constructors = t.GetConstructors();
                    foreach (FieldInfo field in fields)
                        if (field.ToString() == node.Text)
                        {
                            listView1.Clear();
                            ListViewItem item1 = new ListViewItem("field", 0);
                            ListViewItem item2 = new ListViewItem("Name: " + field.Name, 1);
                            ListViewItem item3 = new ListViewItem("access:" +
                                (field.IsPrivate ? " private" : "") +
                                (field.IsPublic ? ", public" : "") +
                                (field.IsStatic ? ", static" : ""), 2);
                            ListViewItem item4 = new ListViewItem("type: " + field.FieldType.Name, 3);
                            listView1.Items.AddRange(new ListViewItem[] { item1, item2, item3, item4 });
                        }

                    foreach (MethodInfo method in methods)
                    {
                        s = "";
                        ParameterInfo[] parametrs = method.GetParameters();
                        foreach (ParameterInfo parametr in parametrs)
                            s += parametr.ParameterType.Name + ", ";
                        s = s.Trim();
                        s = s.TrimEnd(',');
                        String str = method.ReturnType.Name + " " + method.Name + "(" + s + ")";
                        if (str == node.Text)
                        {
                            listView1.Clear();
                            ListViewItem item1 = new ListViewItem("method", 0);
                            ListViewItem item2 = new ListViewItem("Name: " + method.Name, 1);
                            ListViewItem item3 = new ListViewItem("access:" +
                                    (method.IsPrivate ? " private" : "") +
                                    (method.IsPublic ? ", public" : "") +
                                    (method.IsStatic ? ", static" : "") +
                                    (method.IsVirtual ? ", virtual" : "") +
                                    (method.IsFinal ? ", final" : "") +
                                    (method.IsAbstract ? ", abstract" : ""), 2);
                            ListViewItem item4 = new ListViewItem("parameters: " + ((s != "") ? s : "-"), 3);
                            ListViewItem item5 = new ListViewItem("retyrn type: " + method.ReturnType.Name, 4);
                            listView1.Items.AddRange(new ListViewItem[] { item1, item2, item3, item4, item5 });
                        }
                    }

                    foreach (ConstructorInfo constructor in constructors)
                    {
                        s = "";
                        ParameterInfo[] parametrs = constructor.GetParameters();
                        foreach (ParameterInfo parametr in parametrs)
                            s += parametr.ParameterType.Name + ", ";
                        s = s.Trim();
                        s = s.TrimEnd(',');
                        String str = node.Parent.Text + "(" + s + ")";
                        if (str == node.Text)
                        {
                            listView1.Clear();
                            ListViewItem item1 = new ListViewItem("constructor", 0);
                            ListViewItem item2 = new ListViewItem("Name: " + t.Name, 1);
                            ListViewItem item3 = new ListViewItem("access:" +
                                (constructor.IsPrivate ? " private" : "") +
                                (constructor.IsPublic ? ", public" : "") +
                                (constructor.IsStatic ? ", static" : "") +
                                (constructor.IsVirtual ? ", virtual" : "") +
                                (constructor.IsFinal ? ", final" : "") +
                                (constructor.IsAbstract ? ", abstract" : ""), 2);
                            ListViewItem item4 = new ListViewItem("parameters type:  " + ((s != "") ? s : "-"), 3);
                            listView1.Items.AddRange(new ListViewItem[] { item1, item2, item3, item4 });
                        }
                    }
                }
        }


        private void откToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void открытьСборкуToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            treeView1.Nodes.Clear();
            string path = selectAssemblyFile();
            if (path != null)
            {
                assembly = openAssembly(path);
            }
            if (assembly != null)
            {
                TreeNode root = new TreeNode();
                root.Text = assembly.GetName().Name;
                root.ImageIndex = 0;
                root.SelectedImageIndex = 0;
                treeView1.Nodes.Add(root);
                Type[] types = assembly.GetTypes();
                addRoot(root, types);
            }
        }
        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {
            if (treeView1.SelectedNode.Level == 0)
                ShowLevel0(treeView1.SelectedNode);
            if (treeView1.SelectedNode.Level == 1)
                ShowLevel1(treeView1.SelectedNode);
            if (treeView1.SelectedNode.Level == 2)
                ShowLevel2(treeView1.SelectedNode);

        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode selectedNode = treeView1.SelectedNode;
        }
    }
}
